package com.demo.pro.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.demo.pro.entity.Book;

public interface BookInterface extends CrudRepository<Book, Long>{
	
	List<Book> findByStatus(String status);
	
	Book findByBookId(Long bookId);

}
