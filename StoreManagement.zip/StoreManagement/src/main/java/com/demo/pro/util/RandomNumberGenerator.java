package com.demo.pro.util;

import org.springframework.stereotype.Component;

@Component
public class RandomNumberGenerator {

}

