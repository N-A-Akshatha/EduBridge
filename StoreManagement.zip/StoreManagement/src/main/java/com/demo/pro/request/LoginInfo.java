package com.demo.pro.request;

public class LoginInfo {

}
