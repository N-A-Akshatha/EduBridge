package com.demo.pro.service;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.demo.pro.dto.AddressDto;
import com.demo.pro.dto.UpdateAddressDto;
import com.demo.pro.entity.Address;
import com.demo.pro.entity.Users;

@Repository
public interface IAdressService {

	Address addAddress(AddressDto address, String token);

	Users deleteAddress(String token, Long addressId);

	Address updateAddress(UpdateAddressDto address, String token);

	List<Address> getAllAddress();

	Address getAddress(Long id);

	List<Address> getAddressByUserId(String token);

	Address getAddress(String type, String token);

}
