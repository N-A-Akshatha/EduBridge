package com.demo.pro.repository;

import java.util.List;

import com.demo.pro.entity.Users;
import com.demo.pro.request.PasswordUpdate;


public interface IUserRepository {
	Users save(Users users);

	Users getUser(String email);

	boolean verify(Long id);

	boolean upDate(PasswordUpdate information, Long token);

	Users getUserById(Long id );

	List<Users> getUsers();

}

