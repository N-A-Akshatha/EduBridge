package com.demo.pro.service;


import java.util.List;

import com.demo.pro.entity.Order;

public interface OrderService {

	List<Order> getOrderList(String token);

	Order getOrderConfrim(String token);

	int getCountOfBooks(String token);
}
