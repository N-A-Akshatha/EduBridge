package com.demo.pro.dto;

public class Quantitydto {

}
