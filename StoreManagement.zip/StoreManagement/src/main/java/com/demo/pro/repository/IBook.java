package com.demo.pro.repository;

import java.util.List;

import com.demo.pro.entity.Book;

public interface IBook {

	Book save(Book bookinformation);

	List<Book> getUsers();

}
