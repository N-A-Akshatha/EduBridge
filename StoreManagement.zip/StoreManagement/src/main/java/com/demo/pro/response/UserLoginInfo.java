package com.demo.pro.response;

public class UserLoginInfo {

}
