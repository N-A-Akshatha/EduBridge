package com.demo.pro.service;

import java.util.List;

import com.demo.pro.entity.Book;

public interface IAdminService {
	

	boolean verifyBook(long bookId, String staus, String token);


	List<Book> getBooksByStatus(String status);


}
