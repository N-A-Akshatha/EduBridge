package com.demo.pro.service;

import java.util.List;

import com.demo.pro.dto.CartDto;
import com.demo.pro.entity.CartItem;

public interface ICartService {
 List<CartItem> addBooktoCart(String token,long bookId);
 
 List<CartItem> getBooksfromCart(String token);
 
 boolean removeBooksFromCart(String token, Long bookId);
 
 int getCountOfBooks(String token);
 
 CartItem IncreaseBooksQuantityInCart(String token, Long bookId, CartDto bookQuantityDetails);
 
 CartItem descreaseBooksQuantityInCart(String token, Long bookId, CartDto bookQuantityDetails);

 
}
